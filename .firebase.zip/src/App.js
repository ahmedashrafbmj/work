import './App.css';
import AppRouter from './config/Myrouter';

function App() {
  return (
    <>
    <h1>
      hello
    </h1>
      <AppRouter/>
    </>
  );
};

export default App;







